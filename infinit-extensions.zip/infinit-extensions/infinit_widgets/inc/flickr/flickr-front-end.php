<?php
	
	echo $before_widget;
	if ( !empty( $flickr_title ) ) {
		echo $before_title . $flickr_title . $after_title;
	}	
	echo '<ul class="flickr-feed clearfix"></ul>';	
	echo $after_widget;

?>
<script type="text/javascript">
jQuery(document).ready( function($){	
	'use strict';
	$(".flickr-feed").magnificPopup({
		removalDelay: 300,
		disableOn: 400,
		mainClass: 'mfp-with-zoom',
		type: 'image',
		delegate: 'a',
		gallery:{
			enabled:true
		}
	});	
	$('.flickr-feed').jflickrfeed({
		limit: <?php echo $flickr_feed_count ?>,
		qstrings: {
			id: '<?php echo $flickr_feed ?>'
		},
		itemTemplate: '<li><a class="popup" href="{{image_b}}"><img src="{{image_s}}" alt="{{title}}" /></a></li>'
	});
});
</script>
