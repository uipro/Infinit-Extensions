
<script type="text/javascript">
jQuery(document).ready( function($){
	
	'use strict';
	
	$('.flickr-feed').jflickrfeed({
		limit: 6,
		qstrings: {
			id: '<?php echo $flickr_feed ?>'//52617155@N08
		},
		itemTemplate: '<li><a href="{{image_b}}"><img src="{{image_s}}" alt="{{title}}" /></a></li>'
	});
});
</script>