<p>
	<label>Title</label>
	<input class="widefat" name="<?php echo $this->get_field_name('follow_title'); ?>" type="text" value="<?php echo $follow_title; ?>">
</p>