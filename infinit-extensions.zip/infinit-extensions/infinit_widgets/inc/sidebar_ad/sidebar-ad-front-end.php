<div class="aside-widget ad-widget">
	<div class="widget-inner">
		<a class="banner-ad" href="<?php echo esc_url( $ad_link ); ?>" title="<?php echo esc_html__( 'Advertisement', 'infinit-extensions' ); ?>">
			<small class="adv-label text-uppercase text-center"><?php echo esc_html__( '- Advertisement -', 'infinit-extensions' ); ?></small>
			<img class="animate" src="<?php echo esc_url( $ad_img_url ); ?>" alt="<?php echo esc_html__( 'Advertisement', 'infinit-extensions' ); ?>" data-animate="fadeIn" data-duration="1s" data-delay="0.5s">
		</a>
	</div>
</div>