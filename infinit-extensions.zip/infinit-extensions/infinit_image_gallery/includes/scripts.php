<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

/**
 * Scripts
 *
 * @since 1.0
 */
function infinit_image_gallery_scripts() {

	global $post;

	// return if post object is not set
	if ( !isset( $post->ID ) )
		return;


	// JS
	wp_register_script( 'magnific-popup', INFINIT_IMAGE_GALLERY_URL . 'includes/lib/magnific_popup/magnific_popup.js', array( 'jquery' ), INFINIT_IMAGE_GALLERY_VERSION, true );

	// CSS
	wp_register_style( 'magnific-popup', INFINIT_IMAGE_GALLERY_URL . 'includes/lib/magnific_popup/magnific_popup.css', '', INFINIT_IMAGE_GALLERY_VERSION, 'screen' );

	// create a new 'css/infinit-image-gallery.css' in your theme to override CSS file completely
	if ( file_exists( get_stylesheet_directory() . '/css/infinit-image-gallery.css' ) )
		wp_register_style( 'infinit-image-gallery', get_template_directory_uri() . '/css/infinit-image-gallery.css', '', INFINIT_IMAGE_GALLERY_VERSION, 'screen' );
	else
		wp_register_style( 'infinit-image-gallery', INFINIT_IMAGE_GALLERY_URL . 'includes/css/infinit-image-gallery.css', '', INFINIT_IMAGE_GALLERY_VERSION, 'screen' );
		
		wp_enqueue_style( 'infinit-image-gallery' );
					
		// CSS
		wp_enqueue_style( 'magnific-popup' );

		// JS
		wp_enqueue_script( 'magnific-popup' );

		// allow developers to load their own scripts here
		do_action( 'infinit_image_gallery_scripts' );

}
add_action( 'wp_enqueue_scripts', 'infinit_image_gallery_scripts', 20 );




/**
 * JS
 *
 * @since 1.0
 */
function infinit_image_gallery_js() {

ob_start(); ?>

<script>
  jQuery(document).ready(function() {						  
	jQuery(".grid, .image-gallery").magnificPopup({
		removalDelay: 300,
		disableOn: 400,
		mainClass: 'mfp-with-zoom',
		type: 'image',
		delegate: '.popup',
		gallery:{
			enabled:true
		}
	});
  });
</script>

<?php 
	$js = ob_get_clean();
	echo apply_filters( 'infinit_image_gallery_magnificpopup_js', $js );
?>

<?php }
add_action( 'wp_footer', 'infinit_image_gallery_js', 20 );


/**
 * CSS for admin
 *
 * @since 1.0
 */
function infinit_image_gallery_admin_css() { ?>

	<style>
		.attachment.details .check div {
			background-position: -60px 0;
		}

		.attachment.details .check:hover div {
			background-position: -60px 0;
		}

		.gallery_images .details.attachment {
			box-shadow: none;
		}

		.eig-metabox-sortable-placeholder {
			background: #DFDFDF;
		}

		.gallery_images .attachment.details > div {
			width: 150px;
			height: 150px;
			box-shadow: none;
		}

		.gallery_images .attachment-preview .thumbnail {
			 cursor: move;
		}

		.attachment.details div:hover .check {
			display:block;
		}

        .gallery_images:after,
        #gallery_images_container:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }

        .gallery_images > li {
            float: left;
            cursor: move;
            margin: 0 20px 20px 0;
        }

        .gallery_images li.image img {
            width: 150px;
            height: auto;
        }

    </style>

<?php }
add_action( 'admin_head', 'infinit_image_gallery_admin_css' );