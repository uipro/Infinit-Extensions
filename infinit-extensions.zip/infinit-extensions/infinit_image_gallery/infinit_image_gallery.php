<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Infinit_Image_Gallery' ) ) {

	/**
	 * PHP5 constructor method.
	 *
	 * @since 1.0
	*/
	class Infinit_Image_Gallery {

		public function __construct() {
			add_action( 'plugins_loaded', array( $this, 'constants' ));
			add_action( 'plugins_loaded', array( $this, 'includes' ) );
			add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'infinit_image_gallery_plugin_action_links' );
		}


		/**
		 * Constants
		 *
		 * @since 1.0
		*/
		public function constants() {

			if ( !defined( 'INFINIT_IMAGE_GALLERY_DIR' ) )
				define( 'INFINIT_IMAGE_GALLERY_DIR', trailingslashit( plugin_dir_path( __FILE__ ) ) );

			if ( !defined( 'INFINIT_IMAGE_GALLERY_URL' ) )
			    define( 'INFINIT_IMAGE_GALLERY_URL', trailingslashit( plugin_dir_url( __FILE__ ) ) );

			if ( ! defined( 'INFINIT_IMAGE_GALLERY_VERSION' ) )
			    define( 'INFINIT_IMAGE_GALLERY_VERSION', '1.2' );

			if ( ! defined( 'INFINIT_IMAGE_GALLERY_INCLUDES' ) )
			    define( 'INFINIT_IMAGE_GALLERY_INCLUDES', INFINIT_IMAGE_GALLERY_DIR . trailingslashit( 'includes' ) );

		}

		/**
		* Loads the initial files needed by the plugin.
		*
		* @since 1.0
		*/
		public function includes() {

			require_once( INFINIT_IMAGE_GALLERY_INCLUDES . 'template-functions.php' );
			require_once( INFINIT_IMAGE_GALLERY_INCLUDES . 'scripts.php' );
			require_once( INFINIT_IMAGE_GALLERY_INCLUDES . 'metabox.php' );
			require_once( INFINIT_IMAGE_GALLERY_INCLUDES . 'admin-page.php' );

		}

	}
}

$infinit_image_gallery = new Infinit_Image_Gallery();
