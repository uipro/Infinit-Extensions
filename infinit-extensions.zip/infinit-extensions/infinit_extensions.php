<?php
/*
Plugin Name:  Infinit Extensions
Plugin URI:   http://www.uipro.net/
Description:  This plugin is developed to enhance capabilities of Infinit WordPress Theme and to provide some advanced features.
Version:      1.0.0
Author:       Uipro
Author URI:   http://uipro.net/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  infinit-extensions
Domain Path:  /languages
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;


    // Load theme options
    if ( file_exists( dirname( __FILE__ ) . '/infinit_theme_options/admin-init.php' ) ) {
        require_once dirname( __FILE__ ) . '/infinit_theme_options/admin-init.php';
    }
	
    // Load custom widgets
    if ( file_exists( dirname( __FILE__ ) . '/infinit_widgets/infinit_widgets_index.php' ) ) {
        require_once dirname( __FILE__ ) . '/infinit_widgets/infinit_widgets_index.php';
    }
	
    // Post views count
    if ( file_exists( dirname( __FILE__ ) . '/infinit_post_views_count/infinit_post_views_count.php' ) ) {
        require_once dirname( __FILE__ ) . '/infinit_post_views_count/infinit_post_views_count.php';
    }
	
    // Share this post
    if ( file_exists( dirname( __FILE__ ) . '/infinit_share/infinit_share.php' ) ) {
        require_once dirname( __FILE__ ) . '/infinit_share/infinit_share.php';
    }
	
    // Image gallery
    if ( file_exists( dirname( __FILE__ ) . '/infinit_image_gallery/infinit_image_gallery.php' ) ) {
        require_once dirname( __FILE__ ) . '/infinit_image_gallery/infinit_image_gallery.php';
    }
	
    // Load ACF files
    if ( file_exists( dirname( __FILE__ ) . '/advanced-custom-fields/acf.php' ) ) {
		define( 'ACF_LITE', true );
        require_once dirname( __FILE__ ) . '/advanced-custom-fields/acf.php';
    }	
	
	// load plugin text domain
	if( ! function_exists( 'infinit_load_plugin_textdomain' ) ){
		function infinit_load_plugin_textdomain() {
			load_plugin_textdomain( 'infinit-extensions', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
		}
	}
	add_action( 'plugins_loaded', 'infinit_load_plugin_textdomain' );


?>