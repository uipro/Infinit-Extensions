<?php
/*
Plugin Name: Infinit Extensions
Plugin URI: http://www.uipro.net/
Description: This plugin is developed to enhance capabilities of Infinit WordPress Theme and to provide some advanced features.
Author: Uipro
Version: 1.0.0
Author URI: http://uipro.net/
License: Themeforest Standard Licenses
License URI: http://themeforest.net/licenses/standard
Text Domain: infinit-extensions
Domain Path: /languages
*/

/*
NOTE(s):
1. This plugin is specifically developed, to be used with Infinit WordPress Theme, by Uipro.
2. This plugin automatically activates with theme installation.
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;


    // Load theme options
    if ( file_exists( dirname( __FILE__ ) . '/infinit_theme_options/admin-init.php' ) ) {
        require_once dirname( __FILE__ ) . '/infinit_theme_options/admin-init.php';
    }
	
    // Load custom widgets
    if ( file_exists( dirname( __FILE__ ) . '/infinit_widgets/infinit_widgets_index.php' ) ) {
        require_once dirname( __FILE__ ) . '/infinit_widgets/infinit_widgets_index.php';
    }
	
    // Post views count
    if ( file_exists( dirname( __FILE__ ) . '/infinit_post_views_count/infinit_post_views_count.php' ) ) {
        require_once dirname( __FILE__ ) . '/infinit_post_views_count/infinit_post_views_count.php';
    }
	
    // Share this post
    if ( file_exists( dirname( __FILE__ ) . '/infinit_share/infinit_share.php' ) ) {
        require_once dirname( __FILE__ ) . '/infinit_share/infinit_share.php';
    }
	
    // Image gallery
    if ( file_exists( dirname( __FILE__ ) . '/infinit_image_gallery/infinit_image_gallery.php' ) ) {
        require_once dirname( __FILE__ ) . '/infinit_image_gallery/infinit_image_gallery.php';
    }
	
    // Load ACF files
    if ( file_exists( dirname( __FILE__ ) . '/advanced-custom-fields/acf.php' ) ) {
		define( 'ACF_LITE', true );
        require_once dirname( __FILE__ ) . '/advanced-custom-fields/acf.php';
    }


?>