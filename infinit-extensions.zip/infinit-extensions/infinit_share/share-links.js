jQuery( document ).ready( function($){
	
	'use strict';
	// Social Sharing Links
	$(function(){
		 
		createFacebookShare ( $( '.share-this' ).find( '.facebook' ) );
		createTwitterShare ( $( '.share-this' ).find( '.twitter' ) );
		createLinkedinShare ( $( '.share-this' ).find( '.linkedin' ) );
		createGooglePlusShare ( $( '.share-this' ).find( '.google' ) );
		createPinterestShare ( $( '.share-this' ).find( '.pinterest' ) );
		createRedditShare ( $( '.share-this' ).find( '.reddit' ) );		
		createStumbleuponShare ( $( '.share-this' ).find( '.stumbleupon' ) );
		createTumblrShare ( $( '.share-this' ).find( '.tumblr' ) );
		createVkShare ( $( '.share-this' ).find( '.vk' ) );
		createOdnoklassnikiShare ( $( '.share-this' ).find( '.odnoklassniki' ) );
		createPocketShare ( $( '.share-this' ).find( '.pocket' ) );
		createViberShare ( $( '.share-this' ).find( '.viber' ) );
		createWhatsAppShare ( $( '.share-this' ).find( '.whatsapp' ) );
		createTelegramShare ( $( '.share-this' ).find( '.telegram' ) );
		
		// facebook share link
		function createFacebookShare(item) {
            if (item.length && !item.attr('onclick')) {
               item.attr('onclick', "window.open('https://www.facebook.com/sharer/sharer.php?display=popup&u=" + encodeURIComponent(window.location.href) + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=400'); return false;");
            }
        }		
		// twitter share link
		function createTwitterShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('https://twitter.com/intent/tweet?text=" + link_title + "&url=" + encodeURIComponent(window.location.href) + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=300'); return false;");
            }
        }		
		// linkedin share link
		function createLinkedinShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('https://www.linkedin.com/shareArticle?mini=true&url=" + encodeURIComponent(window.location.href) + "&title=" + link_title + "&source=" + encodeURIComponent(window.location.href) + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=300'); return false;");
            }
        }		
		// google plus share link
		 function createGooglePlusShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('//plusone.google.com/_/+1/confirm?hl=en&url=" + encodeURIComponent(window.location.href) + "/&name=" + link_title + "', '_blank', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600'); return false;");
            }
        }		 
		//pinterest share link
		function createPinterestShare(item) {
            if (item.length && !item.attr('onclick')) {
				var thumb_url = $('.featured-img').attr('data-url');
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('https://pinterest.com/pin/create/button/?url=" + encodeURIComponent(window.location.href) + "&description=" + link_title + "&media=" + thumb_url + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=400'); return false;");
            }
        }		
		//reddit share link
		function createRedditShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('https://www.reddit.com/submit?url=" + encodeURIComponent(window.location.href) + "&title=" + link_title + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=400'); return false;");
            }
        }
		//stumbleupon share link
		function createStumbleuponShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('http://www.stumbleupon.com/submit?url=" + encodeURIComponent(window.location.href) + "&title=" + link_title + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=400'); return false;");
            }
        }		
		//tumblr share link
		function createTumblrShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('https://www.tumblr.com/share/link?url=" + encodeURIComponent(window.location.href) + "&name=" + link_title + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=400'); return false;");
            }
        }
		//vk share link
		function createVkShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('https://vk.com/share.php?url=" + encodeURIComponent(window.location.href) + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=400'); return false;");
            }
        }		
		//odnoklassniki share link
		function createOdnoklassnikiShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
				var thumb_url = $('.featured-img').attr('data-url');
                item.attr('onclick', "window.open('https://connect.ok.ru/dk?st.cmd=WidgetSharePreview&st.shareUrl=" + encodeURIComponent(window.location.href) + "&description=" + link_title + "&media=" + thumb_url + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=400'); return false;");
            }
        }
		//pocket share link
		function createPocketShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('https://getpocket.com/save?title=" + link_title + "&url=" + encodeURIComponent(window.location.href) + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=400'); return false;");
            }
        }		
		//viber share link
		function createViberShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('viber://forward/?text=" + link_title + " - " + encodeURIComponent(window.location.href) + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=400'); return false;");
            }
        }		
		//whatsapp share link
		function createWhatsAppShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('whatsapp://send/?text=" + link_title + " - " + encodeURIComponent(window.location.href) + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=400'); return false;");
            }
        }		
		//telegram share link
		function createTelegramShare(item) {
            if (item.length && !item.attr('onclick')) {
				var link_title = $('h1').text();
                item.attr('onclick', "window.open('tg://msg/?text=" + link_title + " - " + encodeURIComponent(window.location.href) + "', '_blank', 'top=100,left=100,toolbar=0,status=0,width=620,height=400'); return false;");
            }
        }
		
	});
	
});