<?php

/* ------------------------------------------------
   *  Post Views and Hits Count
--------------------------------------------------- */

// enqueue post views script
if( ! function_exists( 'infinit_enqueue_custom_scripts' ) ){
	function infinit_enqueue_custom_scripts(){
		
		function infinit_post_views_scripts(){
			wp_enqueue_script( 'infinit_post_views_js', plugins_url( 'infinit-extensions/infinit_post_views_count/infinit_post_views_count.js' ), array('jquery'), '', true );
			wp_localize_script( 'infinit_post_views_js', 'infPostViews', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'inf-views-count-ajax' )
			));
			
		}
		if( is_single() ) {
			add_action( 'wp_enqueue_scripts', 'infinit_post_views_scripts' );
		}
		
	}
}
add_action( 'template_redirect', 'infinit_enqueue_custom_scripts' );


// setting post views
if( ! function_exists( 'infinit_set_post_views' ) ){
	function infinit_set_post_views() {
		if( !current_user_can('publish_posts') ) {
			
			check_ajax_referer( 'inf-views-count-ajax', 'nonce' );
			$post_id = intval( $_POST['post_id'] );
			
			$count_key = 'post_views_count';
			$count = get_post_meta($post_id, $count_key, true);
			if($count=='') {
				$count = 0;
				delete_post_meta($post_id, $count_key);
				add_post_meta($post_id, $count_key, '0');
			} else {
				$count++;
				update_post_meta($post_id, $count_key, $count);
			}
		}
	}
}
add_action( 'wp_ajax_nopriv_infinit_set_post_views', 'infinit_set_post_views' );
add_action( 'wp_ajax_infinit_set_post_views', 'infinit_set_post_views' );


// getting post views
if( ! function_exists( 'infinit_get_post_views' ) ){
	function infinit_get_post_views( $post_id ){
		$views_key = 'post_views_count';
		$count = get_post_meta( $post_id, $views_key, true );
		if($count==''){
			delete_post_meta($post_id, $views_key);
			add_post_meta($post_id, $views_key, '0');
			return "0";
		}
		return $count;
	}
}


// display post 'views' or 'hits' in admin screen
add_filter( 'manage_posts_columns', 'infinit_posts_column_views' );
add_action( 'manage_posts_custom_column', 'infinit_posts_custom_column_views', 5, 2 );
function infinit_posts_column_views( $defaults ){
    $defaults['post_views'] = esc_html__('Views', 'infinit-extensions');
    return $defaults;
}
function infinit_posts_custom_column_views( $column_name, $id ){
	if($column_name === 'post_views'){
		echo infinit_get_post_views( get_the_ID() );
    }
}
 
 
/* ------------------------------------------------
   *  Converts a number into a short version,
   	  eg: 1000 -> 1k
--------------------------------------------------- */
if( ! function_exists( 'infinit_short_number' ) ){
	function infinit_short_number( $n, $precision = 1 ) {
		if ($n < 900) {
			// 0 - 900
			$n_format = number_format($n, $precision);
			$suffix = '';
		} else if ($n < 900000) {
			// 0.9k-850k
			$n_format = number_format($n / 1000, $precision);
			$suffix = 'K';
		} else if ($n < 900000000) {
			// 0.9m-850m
			$n_format = number_format($n / 1000000, $precision);
			$suffix = 'M';
		} else if ($n < 900000000000) {
			// 0.9b-850b
			$n_format = number_format($n / 1000000000, $precision);
			$suffix = 'B';
		} else {
			// 0.9t+
			$n_format = number_format($n / 1000000000000, $precision);
			$suffix = 'T';
		}	
	  // Remove unecessary zeroes after decimal. "1.0" -> "1"; "1.00" -> "1"
	  // Intentionally does not affect partials, eg "1.50" -> "1.50"
		if ( $precision > 0 ) {
			$dotzero = '.' . str_repeat( '0', $precision );
			$n_format = str_replace( $dotzero, '', $n_format );
		}	
		return $n_format . $suffix;
	}
}

?>