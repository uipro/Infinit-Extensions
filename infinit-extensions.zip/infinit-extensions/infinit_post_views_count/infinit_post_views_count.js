jQuery(document).ready( function($){
	
	$.ajax({
		url : infPostViews.ajax_url,
		type : 'post',
		data : {
			action : 'infinit_set_post_views',
			post_id : $('.post').attr('data-id'),
			nonce: infPostViews.nonce
		}
	});
	
});